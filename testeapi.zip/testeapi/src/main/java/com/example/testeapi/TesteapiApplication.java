package com.example.testeapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteapiApplication.class, args);
	}
}
